document.addEventListener("DOMContentLoaded", function () {
    const fileInput = document.getElementById("fileInput");
    const dropZone = document.getElementById("dropZone");
    const status = document.getElementById("status");
    const uploadButton = document.getElementById("uploadButton");
    const uploadWarning = document.getElementById("uploadWarning");

    const externalViewerExtensions = ["docx", "doc", "xlsx", "xls", "pptx", "ppt", "rtf", "odt", "ods", "odp"];
    const blobSafeExtensions = ["pdf", "txt", "png", "jpg", "jpeg", "gif", "bmp", "csv", "mp3", "mp4", "wav"];
    const dataUrlExtensions = ["html", "htm"];

    let selectedFile = null;

    function updateStatus(message, isError = false) {
        status.textContent = message;
        status.className = isError ? 'error' : '';
    }

    async function uploadFile(file) {
        const formData = new FormData();
        formData.append("file", file);
        const response = await fetch("https://tmpfiles.org/api/v1/upload", {
            method: "POST",
            body: formData
        });
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        return data.data.url.replace("https://tmpfiles.org/", "https://tmpfiles.org/dl/");
    }

    async function getDataUrl(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(`data:text/html;charset=utf-8,${encodeURIComponent(reader.result)}`);
            reader.onerror = () => reject(new Error("Failed to read file as data URL"));
            reader.readAsText(file);
        });
    }

    function checkFileAndUpdateUI(file) {
        if (!file) {
            updateStatus("No file provided.", true);
            uploadButton.style.display = "none";
            uploadWarning.style.display = "none";
            selectedFile = null;
            return;
        }
        selectedFile = file;
        updateStatus(`Selected: ${file.name}`);
        uploadButton.style.display = "block";

        const fileExtension = file.name.split('.').pop().toLowerCase();
        if (externalViewerExtensions.includes(fileExtension) || (!blobSafeExtensions.includes(fileExtension) && !dataUrlExtensions.includes(fileExtension))) {
            uploadWarning.style.display = "block";
        } else {
            uploadWarning.style.display = "none";
        }
    }

    async function handleUpload() {
        if (!selectedFile) {
            updateStatus("No file selected to upload.", true);
            return;
        }

        try {
            const fileExtension = selectedFile.name.split('.').pop().toLowerCase();
            let fileURL;

            if (externalViewerExtensions.includes(fileExtension) || (!blobSafeExtensions.includes(fileExtension) && !dataUrlExtensions.includes(fileExtension))) {
                fileURL = await uploadFile(selectedFile);
                updateStatus(`Uploaded to tmpfiles.org: ${selectedFile.name}`);
            } else if (blobSafeExtensions.includes(fileExtension)) {
                fileURL = URL.createObjectURL(selectedFile);
                updateStatus(`Opening locally: ${selectedFile.name}`);
                setTimeout(() => URL.revokeObjectURL(fileURL), 1000);
            } else if (dataUrlExtensions.includes(fileExtension)) {
                fileURL = await getDataUrl(selectedFile);
                updateStatus(`Opening locally as data URL: ${selectedFile.name}`);
            }

            console.log("Opening File URL:", fileURL);
            chrome.runtime.sendMessage({ action: "openFile", fileURL: fileURL });
            updateStatus(`Opened: ${selectedFile.name}`);
        } catch (error) {
            updateStatus(`Error: ${error.message}`, true);
        }
    }

    dropZone.addEventListener("dragover", (event) => {
        event.preventDefault();
        dropZone.style.backgroundColor = "#e0e0e0";
    });

    dropZone.addEventListener("dragleave", () => {
        dropZone.style.backgroundColor = "#f4f4f4";
    });

    dropZone.addEventListener("drop", (event) => {
        event.preventDefault();
        dropZone.style.backgroundColor = "#f4f4f4";
        const file = event.dataTransfer.files[0];
        checkFileAndUpdateUI(file);
    });

    fileInput.addEventListener("change", (event) => {
        const file = event.target.files[0];
        checkFileAndUpdateUI(file);
    });

    dropZone.addEventListener("click", () => fileInput.click());

    uploadButton.addEventListener("click", handleUpload);

    uploadButton.style.display = "none";
    uploadWarning.style.display = "none";
});