document.addEventListener('contextmenu', (event) => {
    const target = event.target;
    let potentialUrl = null;

    if (target.tagName === 'A') {
        return; // Let background.js handle direct links
    }

    if (target.tagName === 'BUTTON' || target.tagName === 'DIV' || target.tagName === 'SPAN') {
        potentialUrl = target.getAttribute('data-file-url') || 
                       target.getAttribute('data-href') || 
                       target.getAttribute('onclick')?.match(/'(https?:\/\/[^\s]+)'/)?.[1] || 
                       target.textContent.trim();
    }

    if (potentialUrl) {
        const fileRegex = /\.(docx|doc|xlsx|xls|pptx|ppt|rtf|odt|ods|odp|pdf|txt|png|jpg|jpeg|gif|bmp|html|htm|csv|mp3|mp4|wav)$/i;
        if (fileRegex.test(potentialUrl)) {
            chrome.runtime.sendMessage({ action: "contextClick", url: potentialUrl });
        }
    }
});