const fileViewers = {
    "docx": "https://view.officeapps.live.com/op/view.aspx?src=",
    "doc": "https://view.officeapps.live.com/op/view.aspx?src=",
    "xlsx": "https://view.officeapps.live.com/op/view.aspx?src=",
    "xls": "https://view.officeapps.live.com/op/view.aspx?src=",
    "pptx": "https://view.officeapps.live.com/op/view.aspx?src=",
    "ppt": "https://view.officeapps.live.com/op/view.aspx?src=",
    "rtf": "https://view.officeapps.live.com/op/view.aspx?src=",
    "odt": "https://view.officeapps.live.com/op/view.aspx?src=",
    "ods": "https://view.officeapps.live.com/op/view.aspx?src=",
    "odp": "https://view.officeapps.live.com/op/view.aspx?src=",
    "pdf": "", "txt": "", "png": "", "jpg": "", "jpeg": "", "gif": "", "bmp": "",
    "html": "", "htm": "", "csv": "", "mp3": "", "mp4": "", "wav": ""
};

chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "openDocuDashViewer",
        title: "Open Document in Browser",
        contexts: ["link"],
        targetUrlPatterns: [
            "*://*/*.docx", "*://*/*.doc", "*://*/*.xlsx", "*://*/*.xls",
            "*://*/*.pptx", "*://*/*.ppt", "*://*/*.rtf",
            "*://*/*.odt", "*://*/*.ods", "*://*/*.odp",
            "*://*/*.pdf", "*://*/*.txt", "*://*/*.png", "*://*/*.jpg",
            "*://*/*.jpeg", "*://*/*.gif", "*://*/*.bmp", "*://*/*.html",
            "*://*/*.htm", "*://*/*.csv", "*://*/*.md", "*://*/*.mp3",
            "*://*/*.mp4", "*://*/*.wav"
        ]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    const url = info.linkUrl;
    const fileExtension = url.split('.').pop().toLowerCase();

    if (fileViewers[fileExtension] !== undefined) {
        const viewerUrl = fileViewers[fileExtension] ? `${fileViewers[fileExtension]}${encodeURIComponent(url)}` : url;
        chrome.tabs.create({ url: viewerUrl });
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "openFile" && message.fileURL) {
        const fileExtension = message.fileURL.split('.').pop().toLowerCase();
        const viewerUrl = fileViewers[fileExtension] ? `${fileViewers[fileExtension]}${encodeURIComponent(message.fileURL)}` : message.fileURL;
        chrome.tabs.create({ url: viewerUrl });
    }
});

chrome.runtime.onStartup.addListener(() => console.log("Background script running"));